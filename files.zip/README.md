# DANA QR MCP Server (Go)

Integrasi QR Code pembayaran **DANA** menggunakan **MCP Server** (Model Context Protocol) dan **SSE** (Server-Sent Events) dengan bahasa Go.

## 📋 Arsitektur

```
┌─────────────────────────────────────────────────────────────┐
│                    HTTP Server (:8080)                       │
├──────────────┬──────────────────┬───────────────────────────┤
│  POST /mcp   │ GET /sse/payment │   POST /webhook/dana      │
│  (MCP/JSONRPC│  (SSE Stream)    │   (Notifikasi DANA)       │
└──────┬───────┴────────┬─────────┴────────────┬──────────────┘
       │                │                       │
       ▼                ▼                       ▼
┌────────────┐  ┌──────────────┐     ┌────────────────────┐
│ MCP Server │  │  SSE Broker  │     │  Webhook Handler   │
│  - Tools   │  │  - Pub/Sub   │◄────│  - Verif Signature │
│  - JSON-RPC│  │  - Channels  │     │  - Update Status   │
└─────┬──────┘  └──────────────┘     └────────────────────┘
      │
      ▼
┌────────────────┐
│  DANA Client   │
│  - Create QR   │
│  - Query QR    │
│  - Cancel QR   │
└────────┬───────┘
         │
         ▼
┌────────────────────────┐
│  DANA API              │
│  api-sandbox.dana.id   │
│  api.dana.id           │
└────────────────────────┘
```

## 🚀 Cara Menjalankan

### 1. Clone & Install Dependencies

```bash
git clone <repo>
cd dana-qr-mcp

# Install dependencies
go mod tidy
```

### 2. Konfigurasi Environment

```bash
cp .env.example .env
# Edit .env dengan credentials DANA Anda
```

### 3. Jalankan Server

```bash
# Development
go run ./cmd/main.go

# Atau build & run
go build -o dana-qr-server ./cmd/main.go
./dana-qr-server
```

Server akan berjalan di: `http://localhost:8080`

---

## 📡 Endpoints

### 1. MCP Server — `POST /mcp`

JSON-RPC 2.0 endpoint. Gunakan ini untuk integrasi dengan Claude atau AI lainnya.

**Tools yang tersedia:**

#### `create_dana_qr` — Buat QR Pembayaran
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "create_dana_qr",
    "arguments": {
      "partnerReferenceNo": "ORDER-001",
      "amount": 50000,
      "description": "Pembayaran Order #001",
      "expiryMinutes": 15
    }
  }
}
```

#### `query_dana_payment` — Cek Status Pembayaran
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "query_dana_payment",
    "arguments": {
      "partnerReferenceNo": "ORDER-001"
    }
  }
}
```

#### `cancel_dana_qr` — Batalkan QR
```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "cancel_dana_qr",
    "arguments": {
      "partnerReferenceNo": "CANCEL-ORDER-001",
      "originalReferenceNo": "DANA-REF-123",
      "reason": "Dibatalkan oleh customer"
    }
  }
}
```

#### `poll_dana_payment` — Polling Otomatis + SSE Updates
```json
{
  "jsonrpc": "2.0",
  "id": 4,
  "method": "tools/call",
  "params": {
    "name": "poll_dana_payment",
    "arguments": {
      "partnerReferenceNo": "ORDER-001",
      "maxAttempts": 20,
      "intervalSeconds": 3
    }
  }
}
```

---

### 2. SSE Stream — `GET /sse/payment?channel={partnerReferenceNo}`

Terima update pembayaran secara real-time.

```javascript
// Contoh penggunaan di JavaScript
const channel = "ORDER-001";
const sse = new EventSource(`http://localhost:8080/sse/payment?channel=${channel}`);

sse.addEventListener("connected", (e) => {
  console.log("Connected:", JSON.parse(e.data));
});

sse.addEventListener("payment_update", (e) => {
  const update = JSON.parse(e.data);
  console.log("Payment Status:", update.status);
  
  if (update.status === "SUCCESS") {
    console.log("✅ Pembayaran berhasil!", update);
    sse.close();
  }
});
```

**Event Types:**
| Event | Keterangan |
|-------|-----------|
| `connected` | Konfirmasi koneksi SSE berhasil |
| `payment_update` | Update status pembayaran |

**Payment Status:**
| Status | Keterangan |
|--------|-----------|
| `INITIATED` | QR baru dibuat |
| `WAITING_PAYMENT` | Menunggu pembayaran |
| `SUCCESS` | Pembayaran berhasil ✅ |
| `FAILED` | Pembayaran gagal ❌ |
| `EXPIRED` | QR sudah expired ⏰ |
| `CANCELLED` | QR dibatalkan 🚫 |

---

### 3. Webhook DANA — `POST /webhook/dana`

Endpoint untuk menerima notifikasi dari DANA saat pembayaran terjadi.

**Konfigurasi di DANA Developer Portal:**
- Notification URL: `https://your-domain.com/webhook/dana`

---

## 🔑 Mendapatkan Credentials DANA

1. Daftar di [DANA Developer Portal](https://devportal.dana.id/)
2. Buat aplikasi baru
3. Dapatkan:
   - **Partner ID** — ID partner Anda
   - **Client ID** — Client identifier
   - **Client Secret** — Secret key
   - **RSA Key Pair** — Generate dan upload public key ke portal DANA

## 🔐 Signature (RSA-SHA256)

Setiap request ke DANA harus disertai signature:

```
StringToSign = HTTPMethod + ":" + RelativePath + ":" + Timestamp + ":" + Lowercase(Base64(SHA256(RequestBody)))
Signature    = Base64(RSA_SHA256_SIGN(PrivateKey, StringToSign))
```

Header yang diperlukan:
```
X-PARTNER-ID: {partnerId}
X-TIMESTAMP:  2024-01-15T10:30:00+07:00
X-SIGNATURE:  {signature}
X-EXTERNAL-ID: {uniqueExternalId}
Authorization: DANA ClientId={clientId},Timestamp={timestamp},Signature={signature}
```

## 🧪 Testing dengan curl

```bash
# 1. Inisialisasi MCP
curl -X POST http://localhost:8080/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}'

# 2. List tools
curl -X POST http://localhost:8080/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/list"}'

# 3. Buat QR
curl -X POST http://localhost:8080/mcp \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
      "name": "create_dana_qr",
      "arguments": {
        "partnerReferenceNo": "TEST-001",
        "amount": 10000,
        "description": "Test Pembayaran"
      }
    }
  }'

# 4. Subscribe SSE (terminal terpisah)
curl -N http://localhost:8080/sse/payment?channel=TEST-001

# 5. Health check
curl http://localhost:8080/health
```

## 📦 Struktur Project

```
dana-qr-mcp/
├── cmd/
│   └── main.go              # Entry point & HTTP server
├── config/
│   └── config.go            # Konfigurasi aplikasi
├── internal/
│   ├── dana/
│   │   ├── client.go        # DANA API HTTP client
│   │   ├── signer.go        # RSA signature utilities
│   │   └── types.go         # Request/response types
│   ├── mcp/
│   │   └── server.go        # MCP server & tool implementations
│   └── sse/
│       └── broker.go        # SSE broker (pub/sub)
├── go.mod
├── .env.example
└── README.md
```
