package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/yourusername/dana-qr-mcp/config"
	"github.com/yourusername/dana-qr-mcp/internal/dana"
	"github.com/yourusername/dana-qr-mcp/internal/mcp"
	"github.com/yourusername/dana-qr-mcp/internal/sse"
)

func main() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	log.Println("🚀 Memulai DANA QR MCP Server...")

	// Load konfigurasi
	cfg := config.DefaultConfig()

	log.Printf("📋 Konfigurasi:")
	log.Printf("   Environment : %s", cfg.Environment)
	log.Printf("   Base URL    : %s", cfg.BaseURL())
	log.Printf("   Partner ID  : %s", cfg.PartnerID)
	log.Printf("   Server      : %s:%d", cfg.ServerHost, cfg.ServerPort)

	// Inisialisasi DANA client
	danaClient, err := dana.NewClient(cfg)
	if err != nil {
		log.Fatalf("❌ Gagal inisialisasi DANA client: %v", err)
	}
	log.Println("✅ DANA client siap")

	// Inisialisasi SSE Broker
	sseBroker := sse.NewBroker()
	log.Println("✅ SSE Broker siap")

	// Inisialisasi MCP Server
	mcpServer := mcp.NewServer(danaClient, sseBroker)
	log.Println("✅ MCP Server siap")

	// Setup HTTP routes
	mux := http.NewServeMux()

	// MCP endpoint (JSON-RPC 2.0 over HTTP)
	mux.HandleFunc("/mcp", mcpServer.HandleMCP)

	// SSE endpoint untuk real-time payment updates
	mux.Handle("/sse/payment", sseBroker)

	// Webhook dari DANA
	mux.HandleFunc("/webhook/dana", mcpServer.HandleNotification)

	// Health check
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, `{"status":"ok","time":"%s","sseClients":%d}`,
			time.Now().Format(time.RFC3339),
			sseBroker.ClientCount(),
		)
	})

	// Demo landing page
	mux.HandleFunc("/", serveDemo)

	// Start server
	addr := fmt.Sprintf("%s:%d", cfg.ServerHost, cfg.ServerPort)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsMiddleware(mux),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 0, // 0 untuk SSE (streaming)
		IdleTimeout:  120 * time.Second,
	}

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGTERM)

	go func() {
		log.Printf("\n📡 Server berjalan di http://%s", addr)
		log.Printf("📌 Endpoint:")
		log.Printf("   POST   http://%s/mcp            → MCP Server (JSON-RPC 2.0)", addr)
		log.Printf("   GET    http://%s/sse/payment     → SSE Stream (real-time updates)", addr)
		log.Printf("   POST   http://%s/webhook/dana    → DANA Notification Webhook", addr)
		log.Printf("   GET    http://%s/health          → Health Check", addr)
		log.Printf("   GET    http://%s/                → Demo Page", addr)

		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("❌ Server error: %v", err)
		}
	}()

	<-quit
	log.Println("\n⏹ Server dihentikan...")
}

// corsMiddleware menambahkan CORS headers
func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}

		next.ServeHTTP(w, r)
	})
}

// serveDemo menampilkan halaman demo sederhana
func serveDemo(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	fmt.Fprint(w, demoHTML)
}

const demoHTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DANA QR MCP Demo</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #f0f4ff; min-height: 100vh; padding: 2rem; }
  .container { max-width: 900px; margin: 0 auto; }
  h1 { color: #1a1a2e; margin-bottom: 0.5rem; }
  .badge { background: #118bee; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
  .card { background: white; border-radius: 12px; padding: 1.5rem; margin-top: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
  h2 { color: #333; margin-bottom: 1rem; font-size: 1.1rem; }
  .field { margin-bottom: 1rem; }
  label { display: block; font-size: 0.85rem; color: #555; margin-bottom: 4px; }
  input { width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 0.95rem; }
  .btn { background: #118bee; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-size: 0.95rem; }
  .btn:hover { background: #0d7ad6; }
  .btn-green { background: #22c55e; }
  .qr-img { max-width: 200px; margin: 1rem auto; display: block; border: 1px solid #eee; border-radius: 8px; }
  .status { padding: 10px; border-radius: 8px; margin-top: 0.5rem; font-size: 0.9rem; }
  .status.success { background: #dcfce7; color: #166534; }
  .status.error { background: #fee2e2; color: #991b1b; }
  .status.info { background: #dbeafe; color: #1e40af; }
  #events { max-height: 200px; overflow-y: auto; border: 1px solid #e5e7eb; border-radius: 8px; padding: 8px; font-size: 0.8rem; font-family: monospace; background: #1a1a2e; color: #7dd3fc; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
  @media (max-width: 600px) { .grid { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<div class="container">
  <h1>🔷 DANA QR MCP Server <span class="badge">Demo</span></h1>
  <p style="color:#666; margin-top:6px">Integrasi QR Code Pembayaran DANA via MCP + SSE</p>
  
  <div class="grid">
    <div class="card">
      <h2>🆕 Buat QR Pembayaran</h2>
      <div class="field"><label>Partner Reference No</label><input id="refNo" value="ORDER-001" /></div>
      <div class="field"><label>Jumlah (IDR)</label><input id="amount" type="number" value="50000" /></div>
      <div class="field"><label>Keterangan</label><input id="desc" value="Pembayaran Order #001" /></div>
      <button class="btn" onclick="createQR()">Buat QR</button>
      <div id="qrResult" style="margin-top:1rem"></div>
    </div>
    
    <div class="card">
      <h2>🔍 Cek Status Pembayaran</h2>
      <div class="field"><label>Partner Reference No</label><input id="queryRef" /></div>
      <button class="btn btn-green" onclick="queryPayment()">Cek Status</button>
      <div id="queryResult" style="margin-top:1rem"></div>
    </div>
  </div>

  <div class="card">
    <h2>📡 SSE Real-time Events</h2>
    <p style="font-size:0.85rem;color:#666;margin-bottom:0.75rem">Update pembayaran akan muncul di sini secara real-time</p>
    <div id="events"><span style="color:#6b7280">-- Menunggu events --</span></div>
  </div>
</div>

<script>
let sseSource = null;

function log(msg, type = 'info') {
  const box = document.getElementById('events');
  const time = new Date().toLocaleTimeString('id-ID');
  box.innerHTML += '<div style="margin-bottom:4px"><span style="color:#9ca3af">['+time+']</span> ' + msg + '</div>';
  box.scrollTop = box.scrollHeight;
}

function connectSSE(channel) {
  if (sseSource) sseSource.close();
  sseSource = new EventSource('/sse/payment?channel=' + channel);
  sseSource.onopen = () => log('🔗 SSE terhubung ke channel: ' + channel);
  sseSource.addEventListener('connected', e => log('✅ ' + JSON.parse(e.data).message));
  sseSource.addEventListener('payment_update', e => {
    const d = JSON.parse(e.data);
    log('💳 Payment Update: ' + d.partnerReferenceNo + ' → <strong style="color:' + 
      (d.status==='SUCCESS'?'#4ade80':d.status==='FAILED'?'#f87171':'#fbbf24') + '">' + d.status + '</strong>');
  });
  sseSource.onerror = () => log('⚠️ SSE error/disconnect', 'error');
}

async function callMCP(method, toolName, args) {
  const res = await fetch('/mcp', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({jsonrpc:'2.0', id:1, method, params:{name:toolName, arguments:args}})
  });
  return res.json();
}

async function createQR() {
  const refNo = document.getElementById('refNo').value;
  const amount = parseFloat(document.getElementById('amount').value);
  const desc = document.getElementById('desc').value;
  const resultDiv = document.getElementById('qrResult');
  
  resultDiv.innerHTML = '<div class="status info">⏳ Membuat QR...</div>';
  
  try {
    const r = await callMCP('tools/call', 'create_dana_qr', {
      partnerReferenceNo: refNo, amount, description: desc
    });
    
    if (r.error) throw new Error(r.error.message);
    
    const data = r.result;
    connectSSE(refNo);
    
    let html = '<div class="status success">✅ QR berhasil dibuat!</div>';
    if (data.qrImageBase64) {
      html += '<img class="qr-img" src="' + data.qrImageBase64 + '" alt="DANA QR" />';
    }
    html += '<div style="font-size:0.8rem;color:#666;margin-top:8px;word-break:break-all"><strong>QR Content:</strong> ' + (data.qrContent || 'N/A') + '</div>';
    html += '<div style="font-size:0.8rem;color:#666;margin-top:4px"><strong>DANA Ref:</strong> ' + (data.referenceNo || '-') + '</div>';
    resultDiv.innerHTML = html;
    document.getElementById('queryRef').value = refNo;
    
    log('🆕 QR dibuat: ' + refNo + ' | Rp ' + amount.toLocaleString('id-ID'));
  } catch(e) {
    resultDiv.innerHTML = '<div class="status error">❌ ' + e.message + '</div>';
    log('❌ Error: ' + e.message);
  }
}

async function queryPayment() {
  const refNo = document.getElementById('queryRef').value;
  const resultDiv = document.getElementById('queryResult');
  
  resultDiv.innerHTML = '<div class="status info">⏳ Mengecek status...</div>';
  
  try {
    const r = await callMCP('tools/call', 'query_dana_payment', {partnerReferenceNo: refNo});
    if (r.error) throw new Error(r.error.message);
    
    const data = r.result;
    const isSuccess = data.isSuccess;
    resultDiv.innerHTML = '<div class="status ' + (isSuccess ? 'success' : 'info') + '">' + 
      (r.result.content ? r.result.content[0].text.replace(/\n/g, '<br>') : JSON.stringify(data, null, 2)) + '</div>';
    
    log('🔍 Query: ' + refNo + ' → ' + data.status);
  } catch(e) {
    resultDiv.innerHTML = '<div class="status error">❌ ' + e.message + '</div>';
  }
}
</script>
</body>
</html>`
