package mcp

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/skip2/go-qrcode"

	"github.com/yourusername/dana-qr-mcp/internal/dana"
	"github.com/yourusername/dana-qr-mcp/internal/sse"
)

// ============================================================
// MCP PROTOCOL TYPES
// ============================================================

// MCPRequest adalah JSON-RPC 2.0 request
type MCPRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      interface{}     `json:"id"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
}

// MCPResponse adalah JSON-RPC 2.0 response
type MCPResponse struct {
	JSONRPC string      `json:"jsonrpc"`
	ID      interface{} `json:"id"`
	Result  interface{} `json:"result,omitempty"`
	Error   *MCPError   `json:"error,omitempty"`
}

// MCPError adalah error JSON-RPC
type MCPError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

// Tool adalah definisi tool MCP
type Tool struct {
	Name        string      `json:"name"`
	Description string      `json:"description"`
	InputSchema interface{} `json:"inputSchema"`
}

// ============================================================
// TOOL PARAMETER TYPES
// ============================================================

type CreateQRParams struct {
	PartnerReferenceNo string  `json:"partnerReferenceNo"`
	Amount             float64 `json:"amount"`      // Dalam IDR (contoh: 50000)
	Currency           string  `json:"currency"`    // Default: IDR
	MerchantID         string  `json:"merchantId,omitempty"`
	Description        string  `json:"description,omitempty"`
	ExpiryMinutes      int     `json:"expiryMinutes,omitempty"` // Default: 15 menit
}

type QueryQRParams struct {
	PartnerReferenceNo string `json:"partnerReferenceNo"`
	ReferenceNo        string `json:"referenceNo,omitempty"`
}

type CancelQRParams struct {
	PartnerReferenceNo  string `json:"partnerReferenceNo"`
	OriginalReferenceNo string `json:"originalReferenceNo"`
	Reason              string `json:"reason,omitempty"`
}

type PollPaymentParams struct {
	PartnerReferenceNo string `json:"partnerReferenceNo"`
	MaxAttempts        int    `json:"maxAttempts,omitempty"` // Default: 10
	IntervalSeconds    int    `json:"intervalSeconds,omitempty"` // Default: 3
}

// ============================================================
// MCP SERVER
// ============================================================

// Server adalah MCP server untuk DANA QR integration
type Server struct {
	danaClient *dana.Client
	sseBroker  *sse.Broker

	// In-memory store untuk tracking QR yang aktif
	mu      sync.RWMutex
	qrStore map[string]*dana.QRData
}

// NewServer membuat MCP server baru
func NewServer(danaClient *dana.Client, sseBroker *sse.Broker) *Server {
	return &Server{
		danaClient: danaClient,
		sseBroker:  sseBroker,
		qrStore:    make(map[string]*dana.QRData),
	}
}

// HandleMCP menangani request MCP via HTTP POST
func (s *Server) HandleMCP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req MCPRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, nil, -32700, "Parse error: "+err.Error())
		return
	}

	log.Printf("[MCP] Request: method=%s id=%v", req.Method, req.ID)

	w.Header().Set("Content-Type", "application/json")

	var result interface{}
	var mcpErr *MCPError

	switch req.Method {
	case "initialize":
		result = s.handleInitialize()

	case "tools/list":
		result = s.handleListTools()

	case "tools/call":
		result, mcpErr = s.handleCallTool(r.Context(), req.Params)

	default:
		mcpErr = &MCPError{Code: -32601, Message: fmt.Sprintf("Method tidak dikenal: %s", req.Method)}
	}

	resp := MCPResponse{
		JSONRPC: "2.0",
		ID:      req.ID,
		Result:  result,
		Error:   mcpErr,
	}

	json.NewEncoder(w).Encode(resp)
}

// handleInitialize menangani inisialisasi MCP
func (s *Server) handleInitialize() interface{} {
	return map[string]interface{}{
		"protocolVersion": "2024-11-05",
		"capabilities": map[string]interface{}{
			"tools": map[string]bool{"listChanged": false},
		},
		"serverInfo": map[string]string{
			"name":    "dana-qr-mcp-server",
			"version": "1.0.0",
		},
	}
}

// handleListTools mengembalikan daftar tools yang tersedia
func (s *Server) handleListTools() interface{} {
	tools := []Tool{
		{
			Name:        "create_dana_qr",
			Description: "Membuat QR Code pembayaran DANA (QRIS). Mengembalikan QR content dan gambar QR dalam format base64.",
			InputSchema: map[string]interface{}{
				"type": "object",
				"properties": map[string]interface{}{
					"partnerReferenceNo": map[string]string{
						"type":        "string",
						"description": "ID unik transaksi dari sistem Anda (max 64 karakter)",
					},
					"amount": map[string]interface{}{
						"type":        "number",
						"description": "Jumlah pembayaran dalam IDR (contoh: 50000 untuk Rp 50.000)",
					},
					"merchantId": map[string]string{
						"type":        "string",
						"description": "Merchant ID DANA (opsional)",
					},
					"description": map[string]string{
						"type":        "string",
						"description": "Keterangan pembayaran",
					},
					"expiryMinutes": map[string]interface{}{
						"type":        "integer",
						"description": "Waktu expired QR dalam menit (default: 15)",
						"default":     15,
					},
				},
				"required": []string{"partnerReferenceNo", "amount"},
			},
		},
		{
			Name:        "query_dana_payment",
			Description: "Mengecek status pembayaran QR DANA berdasarkan partnerReferenceNo",
			InputSchema: map[string]interface{}{
				"type": "object",
				"properties": map[string]interface{}{
					"partnerReferenceNo": map[string]string{
						"type":        "string",
						"description": "ID transaksi yang ingin dicek",
					},
					"referenceNo": map[string]string{
						"type":        "string",
						"description": "Reference number dari DANA (opsional)",
					},
				},
				"required": []string{"partnerReferenceNo"},
			},
		},
		{
			Name:        "cancel_dana_qr",
			Description: "Membatalkan QR pembayaran DANA yang belum dibayar",
			InputSchema: map[string]interface{}{
				"type": "object",
				"properties": map[string]interface{}{
					"partnerReferenceNo": map[string]string{
						"type": "string",
					},
					"originalReferenceNo": map[string]string{
						"type":        "string",
						"description": "Reference number DANA dari QR yang dibuat",
					},
					"reason": map[string]string{
						"type":        "string",
						"description": "Alasan pembatalan",
					},
				},
				"required": []string{"partnerReferenceNo", "originalReferenceNo"},
			},
		},
		{
			Name:        "poll_dana_payment",
			Description: "Polling status pembayaran DANA secara periodik sampai berhasil atau timeout. Mengirim update via SSE.",
			InputSchema: map[string]interface{}{
				"type": "object",
				"properties": map[string]interface{}{
					"partnerReferenceNo": map[string]string{
						"type": "string",
					},
					"maxAttempts": map[string]interface{}{
						"type":    "integer",
						"default": 10,
					},
					"intervalSeconds": map[string]interface{}{
						"type":    "integer",
						"default": 3,
					},
				},
				"required": []string{"partnerReferenceNo"},
			},
		},
	}

	return map[string]interface{}{"tools": tools}
}

// handleCallTool menjalankan tool yang dipanggil
func (s *Server) handleCallTool(ctx context.Context, params json.RawMessage) (interface{}, *MCPError) {
	var callParams struct {
		Name      string          `json:"name"`
		Arguments json.RawMessage `json:"arguments"`
	}

	if err := json.Unmarshal(params, &callParams); err != nil {
		return nil, &MCPError{Code: -32602, Message: "Parameter tidak valid: " + err.Error()}
	}

	switch callParams.Name {
	case "create_dana_qr":
		return s.toolCreateQR(ctx, callParams.Arguments)
	case "query_dana_payment":
		return s.toolQueryPayment(ctx, callParams.Arguments)
	case "cancel_dana_qr":
		return s.toolCancelQR(ctx, callParams.Arguments)
	case "poll_dana_payment":
		return s.toolPollPayment(ctx, callParams.Arguments)
	default:
		return nil, &MCPError{Code: -32601, Message: "Tool tidak ditemukan: " + callParams.Name}
	}
}

// ============================================================
// TOOL IMPLEMENTATIONS
// ============================================================

func (s *Server) toolCreateQR(ctx context.Context, args json.RawMessage) (interface{}, *MCPError) {
	var p CreateQRParams
	if err := json.Unmarshal(args, &p); err != nil {
		return nil, &MCPError{Code: -32602, Message: err.Error()}
	}

	if p.Currency == "" {
		p.Currency = "IDR"
	}
	if p.ExpiryMinutes <= 0 {
		p.ExpiryMinutes = 15
	}
	if p.PartnerReferenceNo == "" {
		p.PartnerReferenceNo = uuid.New().String()
	}

	// Format amount: "50000.00"
	amountStr := fmt.Sprintf("%.2f", p.Amount)

	expiredTime := time.Now().Add(time.Duration(p.ExpiryMinutes) * time.Minute).
		Format("2006-01-02T15:04:05+07:00")

	req := &dana.CreateQRRequest{
		PartnerReferenceNo: p.PartnerReferenceNo,
		Amount: dana.Amount{
			Value:    amountStr,
			Currency: p.Currency,
		},
		MerchantID:  p.MerchantID,
		ExpiredTime: expiredTime,
		AdditionalInfo: map[string]interface{}{
			"description": p.Description,
		},
	}

	resp, err := s.danaClient.CreateQR(ctx, req)
	if err != nil {
		return nil, &MCPError{Code: -32603, Message: "Gagal membuat QR: " + err.Error()}
	}

	// Generate gambar QR dari QRContent
	var qrImageBase64 string
	if resp.QRContent != "" {
		png, err := qrcode.Encode(resp.QRContent, qrcode.Medium, 256)
		if err == nil {
			qrImageBase64 = "data:image/png;base64," + base64.StdEncoding.EncodeToString(png)
		}
	}

	// Simpan ke store
	qrData := &dana.QRData{
		PartnerReferenceNo: resp.PartnerReferenceNo,
		ReferenceNo:        resp.ReferenceNo,
		QRContent:          resp.QRContent,
		QRImageBase64:      qrImageBase64,
		Status:             dana.TransactionStatusInitiated,
		Amount:             amountStr,
		Currency:           p.Currency,
		CreatedAt:          time.Now(),
	}

	s.mu.Lock()
	s.qrStore[p.PartnerReferenceNo] = qrData
	s.mu.Unlock()

	// Kirim event SSE bahwa QR telah dibuat
	s.sseBroker.PublishPaymentUpdate(p.PartnerReferenceNo, sse.PaymentEvent{
		PartnerReferenceNo: resp.PartnerReferenceNo,
		ReferenceNo:        resp.ReferenceNo,
		Status:             dana.TransactionStatusInitiated,
		Amount:             amountStr,
		Currency:           p.Currency,
		Message:            "QR berhasil dibuat, menunggu pembayaran",
	})

	return map[string]interface{}{
		"content": []map[string]interface{}{
			{
				"type": "text",
				"text": fmt.Sprintf("✅ QR DANA berhasil dibuat!\n\nDetail:\n- Partner Reference: %s\n- DANA Reference: %s\n- Jumlah: Rp %s\n- Expired: %s\n- Status: %s",
					resp.PartnerReferenceNo,
					resp.ReferenceNo,
					formatAmount(p.Amount),
					expiredTime,
					dana.TransactionStatusInitiated,
				),
			},
			{
				"type": "text",
				"text": fmt.Sprintf("QR Content: %s", resp.QRContent),
			},
		},
		"qrContent":          resp.QRContent,
		"qrImageBase64":      qrImageBase64,
		"partnerReferenceNo": resp.PartnerReferenceNo,
		"referenceNo":        resp.ReferenceNo,
		"expiredTime":        expiredTime,
		"sseChannel":         p.PartnerReferenceNo,
		"sseEndpoint":        fmt.Sprintf("/sse/payment?channel=%s", p.PartnerReferenceNo),
	}, nil
}

func (s *Server) toolQueryPayment(ctx context.Context, args json.RawMessage) (interface{}, *MCPError) {
	var p QueryQRParams
	if err := json.Unmarshal(args, &p); err != nil {
		return nil, &MCPError{Code: -32602, Message: err.Error()}
	}

	resp, err := s.danaClient.QueryQR(ctx, &dana.QueryQRRequest{
		PartnerReferenceNo: p.PartnerReferenceNo,
		ReferenceNo:        p.ReferenceNo,
	})
	if err != nil {
		return nil, &MCPError{Code: -32603, Message: "Gagal query status: " + err.Error()}
	}

	// Update store dan kirim SSE event
	s.mu.Lock()
	if qr, ok := s.qrStore[p.PartnerReferenceNo]; ok {
		qr.Status = resp.TransactionStatus
	}
	s.mu.Unlock()

	s.sseBroker.PublishPaymentUpdate(p.PartnerReferenceNo, sse.PaymentEvent{
		PartnerReferenceNo: resp.PartnerReferenceNo,
		ReferenceNo:        resp.ReferenceNo,
		Status:             resp.TransactionStatus,
		Amount:             resp.Amount.Value,
		Currency:           resp.Amount.Currency,
		PaidAt:             resp.PaidTime,
	})

	statusEmoji := map[string]string{
		dana.TransactionStatusSuccess:        "✅",
		dana.TransactionStatusFailed:         "❌",
		dana.TransactionStatusExpired:        "⏰",
		dana.TransactionStatusCancelled:      "🚫",
		dana.TransactionStatusWaitingPayment: "⏳",
		dana.TransactionStatusInitiated:      "🔄",
	}

	emoji := statusEmoji[resp.TransactionStatus]
	if emoji == "" {
		emoji = "❓"
	}

	return map[string]interface{}{
		"content": []map[string]interface{}{
			{
				"type": "text",
				"text": fmt.Sprintf("%s Status Pembayaran DANA\n\nPartner Ref: %s\nDANA Ref: %s\nStatus: %s\nJumlah: %s %s",
					emoji,
					resp.PartnerReferenceNo,
					resp.ReferenceNo,
					resp.TransactionStatus,
					resp.Amount.Currency,
					resp.Amount.Value,
				),
			},
		},
		"status":             resp.TransactionStatus,
		"partnerReferenceNo": resp.PartnerReferenceNo,
		"referenceNo":        resp.ReferenceNo,
		"paidTime":           resp.PaidTime,
		"isSuccess":          resp.TransactionStatus == dana.TransactionStatusSuccess,
	}, nil
}

func (s *Server) toolCancelQR(ctx context.Context, args json.RawMessage) (interface{}, *MCPError) {
	var p CancelQRParams
	if err := json.Unmarshal(args, &p); err != nil {
		return nil, &MCPError{Code: -32602, Message: err.Error()}
	}

	cancelRef := fmt.Sprintf("CANCEL-%s-%d", p.PartnerReferenceNo, time.Now().Unix())

	resp, err := s.danaClient.CancelQR(ctx, &dana.CancelQRRequest{
		PartnerReferenceNo:  cancelRef,
		OriginalReferenceNo: p.OriginalReferenceNo,
		Reason:              p.Reason,
	})
	if err != nil {
		return nil, &MCPError{Code: -32603, Message: "Gagal cancel QR: " + err.Error()}
	}

	// Kirim SSE event
	s.sseBroker.PublishPaymentUpdate(p.PartnerReferenceNo, sse.PaymentEvent{
		PartnerReferenceNo: p.PartnerReferenceNo,
		ReferenceNo:        resp.ReferenceNo,
		Status:             dana.TransactionStatusCancelled,
		Message:            "QR dibatalkan: " + p.Reason,
	})

	return map[string]interface{}{
		"content": []map[string]interface{}{
			{
				"type": "text",
				"text": fmt.Sprintf("🚫 QR DANA berhasil dibatalkan\n\nResponse: %s - %s",
					resp.ResponseCode, resp.ResponseMessage),
			},
		},
		"success":         true,
		"responseCode":    resp.ResponseCode,
		"responseMessage": resp.ResponseMessage,
	}, nil
}

func (s *Server) toolPollPayment(ctx context.Context, args json.RawMessage) (interface{}, *MCPError) {
	var p PollPaymentParams
	if err := json.Unmarshal(args, &p); err != nil {
		return nil, &MCPError{Code: -32602, Message: err.Error()}
	}

	if p.MaxAttempts <= 0 {
		p.MaxAttempts = 10
	}
	if p.IntervalSeconds <= 0 {
		p.IntervalSeconds = 3
	}

	// Jalankan polling di goroutine terpisah
	go func() {
		log.Printf("[MCP] Mulai polling payment %s (max %d kali, interval %ds)",
			p.PartnerReferenceNo, p.MaxAttempts, p.IntervalSeconds)

		for attempt := 1; attempt <= p.MaxAttempts; attempt++ {
			select {
			case <-ctx.Done():
				log.Printf("[MCP] Polling dibatalkan untuk %s", p.PartnerReferenceNo)
				return
			case <-time.After(time.Duration(p.IntervalSeconds) * time.Second):
			}

			resp, err := s.danaClient.QueryQR(context.Background(), &dana.QueryQRRequest{
				PartnerReferenceNo: p.PartnerReferenceNo,
			})

			if err != nil {
				log.Printf("[MCP] Polling error attempt %d: %v", attempt, err)
				s.sseBroker.PublishPaymentUpdate(p.PartnerReferenceNo, sse.PaymentEvent{
					PartnerReferenceNo: p.PartnerReferenceNo,
					Status:             "POLLING_ERROR",
					Message:            fmt.Sprintf("Error polling attempt %d: %v", attempt, err),
				})
				continue
			}

			// Kirim update status via SSE
			s.sseBroker.PublishPaymentUpdate(p.PartnerReferenceNo, sse.PaymentEvent{
				PartnerReferenceNo: resp.PartnerReferenceNo,
				ReferenceNo:        resp.ReferenceNo,
				Status:             resp.TransactionStatus,
				Amount:             resp.Amount.Value,
				Currency:           resp.Amount.Currency,
				PaidAt:             resp.PaidTime,
				Message:            fmt.Sprintf("Polling attempt %d/%d", attempt, p.MaxAttempts),
			})

			// Stop jika sudah final
			switch resp.TransactionStatus {
			case dana.TransactionStatusSuccess,
				dana.TransactionStatusFailed,
				dana.TransactionStatusExpired,
				dana.TransactionStatusCancelled:
				log.Printf("[MCP] Polling selesai: %s -> %s",
					p.PartnerReferenceNo, resp.TransactionStatus)
				return
			}
		}

		// Timeout
		s.sseBroker.PublishPaymentUpdate(p.PartnerReferenceNo, sse.PaymentEvent{
			PartnerReferenceNo: p.PartnerReferenceNo,
			Status:             "POLLING_TIMEOUT",
			Message:            fmt.Sprintf("Polling timeout setelah %d percobaan", p.MaxAttempts),
		})
	}()

	return map[string]interface{}{
		"content": []map[string]interface{}{
			{
				"type": "text",
				"text": fmt.Sprintf("⏳ Polling dimulai untuk transaksi %s\n\nUpdate status akan dikirim via SSE ke:\n/sse/payment?channel=%s\n\nMax percobaan: %d, Interval: %ds",
					p.PartnerReferenceNo,
					p.PartnerReferenceNo,
					p.MaxAttempts,
					p.IntervalSeconds,
				),
			},
		},
		"polling":    true,
		"sseChannel": p.PartnerReferenceNo,
		"sseEndpoint": fmt.Sprintf("/sse/payment?channel=%s", p.PartnerReferenceNo),
	}, nil
}

// ============================================================
// WEBHOOK HANDLER
// ============================================================

// HandleNotification menangani webhook notifikasi dari DANA
func (s *Server) HandleNotification(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var payload dana.NotificationPayload
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		log.Printf("[MCP] Error decode notification: %v", err)
		http.Error(w, "Bad request", http.StatusBadRequest)
		return
	}

	log.Printf("[MCP] Notifikasi DANA diterima: partnerRef=%s, status=%s",
		payload.PartnerReferenceNo, payload.TransactionStatus)

	// TODO: Verifikasi signature dari DANA

	// Update QR store
	s.mu.Lock()
	if qr, ok := s.qrStore[payload.PartnerReferenceNo]; ok {
		qr.Status = payload.TransactionStatus
		if payload.TransactionStatus == dana.TransactionStatusSuccess {
			t := time.Now()
			_ = t
		}
	}
	s.mu.Unlock()

	// Kirim event ke semua client yang listening via SSE
	s.sseBroker.PublishPaymentUpdate(payload.PartnerReferenceNo, sse.PaymentEvent{
		PartnerReferenceNo: payload.PartnerReferenceNo,
		ReferenceNo:        payload.ReferenceNo,
		Status:             payload.TransactionStatus,
		Amount:             payload.PaidAmount.Value,
		Currency:           payload.PaidAmount.Currency,
		PaidAt:             payload.PaidTime,
		Message:            "Notifikasi dari DANA",
	})

	// Response ke DANA (harus 200 OK)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"responseCode":    "2005400",
		"responseMessage": "SUCCESS",
	})
}

// ============================================================
// HELPER
// ============================================================

func writeError(w http.ResponseWriter, id interface{}, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(MCPResponse{
		JSONRPC: "2.0",
		ID:      id,
		Error:   &MCPError{Code: code, Message: msg},
	})
}

func formatAmount(amount float64) string {
	return fmt.Sprintf("%,.0f", amount)
}
