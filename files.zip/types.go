package dana

import "time"

// ============================================================
// REQUEST & RESPONSE TYPES
// ============================================================

// CreateQRRequest adalah request untuk membuat QR Code pembayaran DANA
type CreateQRRequest struct {
	// Merchant order ID yang unik dari sistem partner
	PartnerReferenceNo string `json:"partnerReferenceNo"`

	// Jumlah pembayaran dalam IDR (dalam satuan sen, misal: 10000 = Rp 100.00)
	Amount Amount `json:"amount"`

	// Deskripsi/keterangan pembayaran
	MerchantID   string `json:"merchantId,omitempty"`
	SubMerchantID string `json:"subMerchantId,omitempty"`

	// Expiry time untuk QR
	ExpiredTime string `json:"expiredTime,omitempty"`

	// Additional info
	AdditionalInfo map[string]interface{} `json:"additionalInfo,omitempty"`
}

// Amount representasi jumlah uang
type Amount struct {
	Value    string `json:"value"`    // Format: "10000.00"
	Currency string `json:"currency"` // "IDR"
}

// CreateQRResponse adalah response dari pembuatan QR Code
type CreateQRResponse struct {
	ResponseCode    string `json:"responseCode"`
	ResponseMessage string `json:"responseMessage"`

	// Data QR yang dihasilkan
	PartnerReferenceNo string `json:"partnerReferenceNo"`
	ReferenceNo        string `json:"referenceNo"`

	// QR Code content (string yang di-encode menjadi QR)
	QRContent string `json:"qrContent"`

	// URL gambar QR (opsional, tergantung implementasi)
	QRUrl string `json:"qrUrl,omitempty"`

	// Waktu expired QR
	ExpiredTime string `json:"expiredTime,omitempty"`

	AdditionalInfo map[string]interface{} `json:"additionalInfo,omitempty"`
}

// QueryQRRequest untuk mengecek status pembayaran
type QueryQRRequest struct {
	PartnerReferenceNo string `json:"partnerReferenceNo"`
	ReferenceNo        string `json:"referenceNo,omitempty"`
	MerchantID         string `json:"merchantId,omitempty"`
}

// QueryQRResponse response status pembayaran
type QueryQRResponse struct {
	ResponseCode    string `json:"responseCode"`
	ResponseMessage string `json:"responseMessage"`

	PartnerReferenceNo string `json:"partnerReferenceNo"`
	ReferenceNo        string `json:"referenceNo"`

	// Status: INITIATED, WAITING_PAYMENT, SUCCESS, FAILED, EXPIRED, CANCELLED
	TransactionStatus string `json:"transactionStatus"`

	Amount          Amount `json:"amount,omitempty"`
	PaidAmount      Amount `json:"paidAmount,omitempty"`
	PaidTime        string `json:"paidTime,omitempty"`

	AdditionalInfo map[string]interface{} `json:"additionalInfo,omitempty"`
}

// CancelQRRequest untuk membatalkan QR
type CancelQRRequest struct {
	PartnerReferenceNo    string `json:"partnerReferenceNo"`
	OriginalReferenceNo   string `json:"originalReferenceNo"`
	MerchantID            string `json:"merchantId,omitempty"`
	Reason                string `json:"reason,omitempty"`
}

// CancelQRResponse response pembatalan QR
type CancelQRResponse struct {
	ResponseCode       string `json:"responseCode"`
	ResponseMessage    string `json:"responseMessage"`
	PartnerReferenceNo string `json:"partnerReferenceNo"`
	ReferenceNo        string `json:"referenceNo"`
}

// NotificationPayload adalah payload yang diterima dari DANA saat pembayaran berhasil
type NotificationPayload struct {
	PartnerReferenceNo string `json:"partnerReferenceNo"`
	ReferenceNo        string `json:"referenceNo"`
	TransactionStatus  string `json:"transactionStatus"`
	Amount             Amount `json:"amount"`
	PaidAmount         Amount `json:"paidAmount"`
	PaidTime           string `json:"paidTime"`
	MerchantID         string `json:"merchantId"`
	AdditionalInfo     map[string]interface{} `json:"additionalInfo,omitempty"`
	Signature          string `json:"signature"`
}

// ============================================================
// INTERNAL TYPES
// ============================================================

// PaymentStatus representasi status pembayaran internal
type PaymentStatus struct {
	PartnerReferenceNo string
	ReferenceNo        string
	Status             string
	Amount             string
	Currency           string
	PaidAt             *time.Time
	UpdatedAt          time.Time
}

// QRData menyimpan informasi lengkap QR yang dibuat
type QRData struct {
	PartnerReferenceNo string
	ReferenceNo        string
	QRContent          string
	QRImageBase64      string // Base64 encoded QR image
	ExpiredAt          time.Time
	Status             string
	Amount             string
	Currency           string
	CreatedAt          time.Time
}

// ============================================================
// RESPONSE CODES
// ============================================================

const (
	ResponseCodeSuccess = "2005400"
	ResponseCodePending = "0235400"

	TransactionStatusInitiated      = "INITIATED"
	TransactionStatusWaitingPayment = "WAITING_PAYMENT"
	TransactionStatusSuccess        = "SUCCESS"
	TransactionStatusFailed         = "FAILED"
	TransactionStatusExpired        = "EXPIRED"
	TransactionStatusCancelled      = "CANCELLED"
)
